#ifndef _h_ACTION
#define _h_ACTION 1

#include "osdep.h"

PUBLIC void action_get(HttpConn *conn);
PUBLIC void action_post(HttpConn *conn);

#endif /* _h_ACTION */