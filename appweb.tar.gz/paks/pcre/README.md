Perl Compatible Regular Expressions
===

Licensing
---
See LICENSE.md for details.

### To Read Documentation:

  See doc/index.html

### Prerequisites:

    MakeMe (https://www.embedthis.com/makeme/) for MakeMe to configure and build.

### To Build:

    ./configure
    me

Alternatively to build MakeMe:

    make

### To Create Packages:

    me package

Resources
---
  - [Embedthis web site](https://www.embedthis.com/)
