License
===

This software is distributed under commercial and GPL open source licenses.
The GPL License does not generally permit incorporating this software into
non-open source programs. Commercial licenses for this software and support
services are available.

Trademarks and Copyrights
---
Copyright (c) Michael O'Brien. All Rights Reserved.
