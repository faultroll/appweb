Embedthis License
===

This software is distributed under the GPL open source license.

* [GPL License](http://www.gnu.org/licenses/gpl-2.0.html)

This software is also distributed under the Embedthis Open Source
license which is an MIT style license if used with an Embedthis
Commercial License.

* [Embedthis Extension License](https://embedthis.com/licensing/extension.html)

Trademarks and Copyrights
---
Copyright (c) Embedthis Software. All Rights Reserved.
Embedthis and Embedthis ESP are trademarks of Embedthis Software, LLC.
Other brands and their products are trademarks of their respective holders.
